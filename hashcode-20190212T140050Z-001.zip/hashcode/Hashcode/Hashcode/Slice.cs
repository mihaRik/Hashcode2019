﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashcode
{
    class Slice
    {
        public List<Piece> Pieces { get; set; }

        public string GetStartPoint()
        {
            return $"({Pieces[0].RX},{Pieces[0].CX}) ({Pieces[0].RY},{Pieces[0].CY})";
        }

        public string GetEndPoint()
        {
            return $"({Pieces[Pieces.Count - 1].RX},{Pieces[Pieces.Count - 1].CX}) ({Pieces[Pieces.Count - 1].RY},{Pieces[Pieces.Count - 1].CY})";
        }
    }
}
