﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashcode
{
    class Piece
    {
        public int RX { get; set; }
        public int RY { get; set; }
        public int CX { get; set; }
        public int CY { get; set; }
    }
}
