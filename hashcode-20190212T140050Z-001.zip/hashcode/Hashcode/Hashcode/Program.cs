﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashcode
{
    class Program
    {
        static void Main(string[] args)
        {
            //FileStream file = new FileStream(@"C:\Users\RahimRt\Desktop\hashcode\a_example.in", FileMode.Open);
            //byte[] array = new byte[file.Length];
            //var a = file.Read(array, 0, (int)file.Length);

            StreamReader stream = new StreamReader(@"C:\Users\RahimRt\Desktop\hashcode\a_example.in");

            var rules = stream.ReadLine();
            var a = rules.Split(' ');
            var r = Convert.ToInt32(a[0]);
            var c = Convert.ToInt32(a[1]);
            var l = Convert.ToInt32(a[2]);
            var h = Convert.ToInt32(a[3]);
            var arr = new string[r, c];
            var text = stream.ReadToEnd();
            text = text.Replace("\n", null);
            var rLength = arr.GetLength(0);
            var cLength = arr.GetLength(1);
            var mCount = text.Count(x => x == 'M');
            var tCount = text.Count(x => x == 'T');
            var pizza = new char[r, c];
            List<Slice> slices = new List<Slice>();

            for (int y = 0; y < r; y++)
            {
                for (int x = 0; x < c; x++)
                {
                    pizza[y, x] = text[y * c + x];
                }
            }
            //Slice slice = new Slice();
            //slice.Pieces.Add(piece);
            //for (int i = 0; i < 5; i++)
            //{
            //    text[y]
            //}
            //Piece piece = new Piece()
            //{

            //};
            //text[y * c + x]
            
            for (int y = 0; y < r; y++)
            {
                for (int x = 0; x < c; x++)
                {

                }
            }
            stream.Close();
        }
    }
}
