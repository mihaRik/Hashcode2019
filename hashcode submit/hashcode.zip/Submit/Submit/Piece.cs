﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Submit
{
    public class Piece
    {
        public int RS { get; set; }
        public int CS { get; set; }
        public char Value { get; set; }
    }
}
